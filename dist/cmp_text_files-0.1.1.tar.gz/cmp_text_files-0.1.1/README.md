Comparison of text files

A library for a comparison of text files.

Installation
pip install cmp_text_files

Get started
How to compare one text file with another file:

from cmp_text_files import Comparison

# Instantiate a Comparison object
comparison = Comparison()

# Call the compare method
comparison.compare()