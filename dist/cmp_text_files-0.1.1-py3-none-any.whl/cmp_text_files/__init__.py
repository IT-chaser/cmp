# This line of code will allow shorter imports
from cmp_text_files.comparison import Comparison